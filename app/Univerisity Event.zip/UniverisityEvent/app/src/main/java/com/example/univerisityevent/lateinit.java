package com.example.univerisityevent;

public class lateinit {
}
